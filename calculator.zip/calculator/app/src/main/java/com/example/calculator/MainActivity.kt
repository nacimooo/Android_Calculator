package com.example.calculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.calculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        var arr = arrayOf(0,0,0,0,0)
//        var pos: Int = 0

        // set the values for the calculation states
        var isMul: Int = 0
        var isAdd: Int = 0
        var isMin: Int = 0

        // set values for the data variables
        var First: Int = 0
        var Second: Int = 0
        var Result: Int = 0
        var isDigit: Int = 0

        // check if the a button was presses and if so, check which var it should go to.
        binding.button.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 1
                    binding.textView.text = "1"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 1
                    binding.textView.append("1")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 1
                    binding.textView.text = "1"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 1
                    binding.textView.append("1")
                }
            }
        }
        binding.button2.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 2
                    binding.textView.text = "2"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 2
                    binding.textView.append("2")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 2
                    binding.textView.text = "2"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 2
                    binding.textView.append("2")
                }
            }
        }
        binding.button3.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 3
                    binding.textView.text = "3"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 3
                    binding.textView.append("3")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 3
                    binding.textView.text = "3"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 3
                    binding.textView.append("3")
                }
            }
        }
        binding.button4.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 4
                    binding.textView.text = "4"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 4
                    binding.textView.append("4")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 4
                    binding.textView.text = "4"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 4
                    binding.textView.append("4")
                }
            }
        }
        binding.button5.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 5
                    binding.textView.text = "5"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 5
                    binding.textView.append("5")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 5
                    binding.textView.text = "5"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 5
                    binding.textView.append("5")
                }
            }
        }
        binding.button6.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 6
                    binding.textView.text = "6"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 6
                    binding.textView.append("6")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 6
                    binding.textView.text = "6"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 6
                    binding.textView.append("6")
                }
            }
        }
        binding.button7.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 7
                    binding.textView.text = "7"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 7
                    binding.textView.append("7")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 7
                    binding.textView.text = "7"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 7
                    binding.textView.append("7")
                }
            }
        }
        binding.button8.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 8
                    binding.textView.text = "8"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 8
                    binding.textView.append("8")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 8
                    binding.textView.text = "8"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 8
                    binding.textView.append("8")
                }
            }
        }
        binding.button9.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 9
                    binding.textView.text = "9"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 9
                    binding.textView.append("9")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 9
                    binding.textView.text = "9"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 9
                    binding.textView.append("9")
                }
            }
        }
        binding.button0.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                if (isDigit == 0) {
                    First = 0
                    binding.textView.text = "0"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 0
                    binding.textView.append("0")
                }
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                if (isDigit == 0) {
                    Second = 0
                    binding.textView.text = "0"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 0
                    binding.textView.append("0")
                }
            }
        }

        // what to do if a button was pressed
        binding.buttonPlus.setOnClickListener {
            isAdd = 1
            isMul = 0
            isMin = 0
            isDigit = 0
        }

        binding.buttonMinus.setOnClickListener {
            isAdd = 0
            isMul = 0
            isMin = 1
            isDigit = 0
        }

        binding.buttonMul.setOnClickListener {
            isAdd = 0
            isMul = 1
            isMin = 0
            isDigit = 0
        }

        // do the calculations once the equals button is pressed
        binding.buttonEqual.setOnClickListener {
            // check which calculation to perform
            if (isAdd == 1){
                Result = First + Second
                binding.textView.text = Result.toString()
            }
            if (isMul == 1){
                Result = First * Second
                binding.textView.text = Result.toString()
            }
            if (isMin == 1){
                Result = First - Second
                binding.textView.text = Result.toString()
            }
            // clear the registers for the calculation states
            isAdd = 0
            isMul = 0
            isMin = 0
            isDigit = 0

            // has an ans feature
            First = Result
        }

        // clear the registers and start a fresh
        binding.buttonClear.setOnClickListener {
            binding.textView.text = "0"
            isAdd = 0
            isMul = 0
            isMin = 0
            First = 0
            Second = 0
            Result = 0
            isDigit = 0
        }

        binding.buttonAbout.setOnClickListener {
            val intent = Intent(this, AboutScreen::class.java)
            startActivity(intent)
            startActivity(intent)
        }
    }
}