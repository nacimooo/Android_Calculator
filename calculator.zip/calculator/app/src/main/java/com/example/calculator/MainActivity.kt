package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.calculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        var arr = arrayOf(0,0,0,0,0)
//        var pos: Int = 0
        var isMul: Int = 0
        var isAdd: Int = 0
        var isMin: Int = 0


        var First: Int = 0
        var Second: Int = 0
        var Result: Int = 0

        binding.button.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 1
                binding.textView.text = "1"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 1
                binding.textView.text = "1"
            }
        }
        binding.button2.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 2
                binding.textView.text = "2"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 2
                binding.textView.text = "2"
            }
        }
        binding.button3.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 3
                binding.textView.text = "3"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 3
                binding.textView.text = "3"
            }
        }
        binding.button4.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 4
                binding.textView.text = "4"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 4
                binding.textView.text = "4"
            }
        }
        binding.button5.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 5
                binding.textView.text = "5"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 5
                binding.textView.text = "5"
            }
        }
        binding.button6.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 6
                binding.textView.text = "6"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 6
                binding.textView.text = "6"
            }
        }
        binding.button7.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 7
                binding.textView.text = "7"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 7
                binding.textView.text = "7"
            }
        }
        binding.button8.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 8
                binding.textView.text = "8"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 8
                binding.textView.text = "8"
            }
        }
        binding.button9.setOnClickListener {
            if (isMul == 0 && isAdd == 0 && isMin == 0){
                First = 9
                binding.textView.text = "9"
            }
            if (isMul == 1 || isAdd == 1 || isMin == 1){
                Second = 9
                binding.textView.text = "9"
            }
        }
        binding.buttonPlus.setOnClickListener {
            isAdd = 1
            isMul = 0
            isMin = 0
        }

        binding.buttonMinus.setOnClickListener {
            isAdd = 0
            isMul = 0
            isMin = 1
        }

        binding.buttonMul.setOnClickListener {
            isAdd = 0
            isMul = 1
            isMin = 0
        }
        binding.buttonEqual.setOnClickListener {
            if (isAdd == 1){
                Result = First + Second
                binding.textView.text = Result.toString()
            }
            if (isMul == 1){
                Result = First * Second
                binding.textView.text = Result.toString()
            }
            if (isMin == 1){
                Result = First - Second
                binding.textView.text = Result.toString()
            }
            isAdd = 0
            isMul = 0
            isMin = 0
        }

    }
}